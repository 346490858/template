package example.json;

import org.apache.log4j.Logger;

import com.dahantc.api.sms.json.JSONHttpClient;

public class HttpJsonTemplateExample {
	private static final Logger LOG = Logger.getLogger(HttpJsonTemplateExample.class);
	private static String account = "dh*****"; // 用户名（必填）
	private static String password = "******"; // 密码（必填）
	private static String content = "你好，这是白模板${1,10}示例"; // 模板内容（必填）
	public static String sign = ""; // 短信签名（必填，格式如【大汉三通】）
	public static String templateIds = ""; // 查询或删除的模板id（多个以逗号分隔）

	public static void main(String[] args) {
		try {
			JSONHttpClient jsonHttpClient = new JSONHttpClient("http://www.dh3t.com");
			jsonHttpClient.setRetryCount(1);

			String uploadResult = jsonHttpClient.uploadTemplate(account, password, content, sign);
			LOG.info("上传模板响应：" + uploadResult);

			String showResult = jsonHttpClient.showTemplate(account, password, templateIds);
			LOG.info("查询模板响应：" + showResult);

			String deleteResult = jsonHttpClient.deleteTemplate(account, password, templateIds);
			LOG.info("删除模板响应：" + deleteResult);
		} catch (Exception e) {
			LOG.error("应用异常", e);
		}
	}
}
